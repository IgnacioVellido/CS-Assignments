void daxpy (double *x, double *y, int N, int a) {
  int i;

  for (i=0; i<N; i++) {
    y[i] = a*x[i] + y[i];
  }
}
