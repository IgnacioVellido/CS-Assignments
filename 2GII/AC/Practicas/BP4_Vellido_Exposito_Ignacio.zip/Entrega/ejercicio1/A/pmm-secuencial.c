void pmm(long int **A, long int **B, long int **C, int N) {
  int i, j, k;
  long int suma;

  for (i=0; i<N; i++) {
    for (j=0; j<N; j++) {
      suma = 0;

      for (k=0 ; k<N; k++)
        suma += A[i][k] * B[k][j];

      C[i][j] = suma;
    }
  }
}
