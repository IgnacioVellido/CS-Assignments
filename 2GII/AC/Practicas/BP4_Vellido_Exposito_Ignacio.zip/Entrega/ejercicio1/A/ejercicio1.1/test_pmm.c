// Resuelto para matrices de enteros

#include <stdlib.h>	// biblioteca con funciones atoi(), malloc() y free()
#include <stdio.h>      // biblioteca donde se encuentra la función printf()
#include <time.h>	// biblioteca donde se encuentra la función clock_gettime()


void pmm(long int **A, long int **B, long int **C, int N);

int main (int argc, char **argv) {
  int N;

  if (argc != 2) {
    printf("Falta el tamanio de la matriz cuadrada\n");
    exit(1);
  }

  N = atoi(argv[1]);


  long int **A, **B, **C;
  A = (long int**) malloc(N*sizeof(long int *));
  B = (long int**) malloc(N*sizeof(long int *));
  C = (long int**) malloc(N*sizeof(long int *));

  int p;
  for (p=0; p<N; p++) {
    A[p] = (long int*) malloc(N*sizeof(long int));
    B[p] = (long int*) malloc(N*sizeof(long int));
    C[p] = (long int*) malloc(N*sizeof(long int));
  }

  if ( (A==NULL) || (B==NULL) || (C==NULL) ){
    printf("Error en la reserva de espacio\n");
    exit(-2);
  }

  int i, j, k;

  // Inicialización
  for (i=0; i<N; i++) {
    for (j=0; j<N; j++) {
        A[i][j] = j+1;
        B[i][j] = j+1;
    }
  }

  struct timespec cgt1,cgt2; double ncgt; //para tiempo de ejecución

  // Mediciones
  clock_gettime(CLOCK_REALTIME,&cgt1);

  pmm(A, B, C, N);

  clock_gettime(CLOCK_REALTIME,&cgt2);

  // Calculo de tiempos
  ncgt=(double) (cgt2.tv_sec-cgt1.tv_sec)+
       (double) ((cgt2.tv_nsec-cgt1.tv_nsec)/(1.e+9));

  // Para tamaños pequeños imprimir todas las componentes
  printf("Tiempo(seg.):%11.9f\t / Tamaño Vectores:%u\n",ncgt,N);


  printf("C[0][0]=%li, C[%d][%d]=%li\n",
		C[0][0], N-1, N-1, C[N-1][N-1]);

  // Liberar memoria
  for (p=0; p<N; p++) {
    free(A[p]);
    free(B[p]);
    free(C[p]);
  }

  free(A); free(B); free(C);
}
