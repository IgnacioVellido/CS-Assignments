/*
  Modificiación: Calcular traspuesta - Menos fallos en línea de caché (último for)
*/

#include <stdlib.h>

void pmm(long int **A, long int **B, long int **C, int N) {
  int i, j, k;
  long int suma1, suma2, suma3, suma4;

  // Reservar memoria para la traspuesta
  long int **D = (long int**) malloc(N*sizeof(long int *));
  for (i=0; i<N; i++)
    D[i] = (long int*) malloc(N*sizeof(long int));

  // Calcular traspuesta
  for (i=0; i<N; i++)
    for (j=0; j<N; j++)
      D[i][j] = B[j][i];


  // Multiplicación
  for (i=0; i<N; i++) {
    for (j=0; j<N; j+=4) {
      suma1 = suma2 = suma3 = suma4 = 0;

      for (k=0 ; k<N; k++) {
        suma1 += A[i][k] * D[j][k];
        suma2 += A[i][k] * D[j+1][k];
        suma3 += A[i][k] * D[j+2][k];
        suma4 += A[i][k] * D[j+3][k];
      }

      C[i][j] = suma1;
      C[i][j+1] = suma2;
      C[i][j+2] = suma3;
      C[i][j+3] = suma4;
    }

  }

  // Liberar memoria
  for (i=0; i<N; i++)
    free(D[i]);

  free(D);
}
