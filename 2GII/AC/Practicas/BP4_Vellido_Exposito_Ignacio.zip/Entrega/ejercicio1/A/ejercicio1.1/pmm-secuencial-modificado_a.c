/*
  Modificiación:  
  Desenrrollado de bucle, suponemos que es múltiplo de 4 el tamaño de la matriz (habría que comprobarlo en otro caso)
*/

void pmm(long int **A, long int **B, long int **C, int N) {
  int i, j, k;
  long int suma1, suma2, suma3, suma4;

  for (i=0; i<N; i++) {

    for (j=0; j<N; j+=4) {
      suma1 = suma2 = suma3 = suma4 = 0;

      for (k=0 ; k<N; k++) {
        suma1 += A[i][k] * B[k][j];
        suma2 += A[i][k] * B[k][j+1];
        suma3 += A[i][k] * B[k][j+2];
        suma4 += A[i][k] * B[k][j+3];
      }

      C[i][j] = suma1;
      C[i][j+1] = suma2;
      C[i][j+2] = suma3;
      C[i][j+3] = suma4;
    }
  }
}
