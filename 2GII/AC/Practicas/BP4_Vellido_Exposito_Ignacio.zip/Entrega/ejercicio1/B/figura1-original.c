#include <stdio.h>
#include <time.h>

struct {
  int a;
  int b;
} s[5000];

int main() {
  /* ------------ */
  int i,j,
      x1,x2,
      r[40000];
  /* ------------ */

  // Inicialización
  for (j=0; j<5000; j++) s[j].a = s[j].b = 1;

  struct timespec cgt1,cgt2; double ncgt; 

  clock_gettime(CLOCK_REALTIME,&cgt1);

  /* ---------------------------------- */

  for (i=0; i<40000; i++) {
    x1=0; x2=0;

    for (j=0; j<5000; j++) x1 += 2*s[j].a+i;
    for (j=0; j<5000; j++) x2 += 3*s[j].b-i;

    if (x1<x2)
      r[i] = x1;
    else 
      r[i] = x2;
  }

  /* ---------------------------------- */

  clock_gettime(CLOCK_REALTIME,&cgt2);

  // Calculo de tiempos
  ncgt=(double) (cgt2.tv_sec-cgt1.tv_sec)+
       (double) ((cgt2.tv_nsec-cgt1.tv_nsec)/(1.e+9));

  printf("Tiempo=%11.9f\n", ncgt);
  printf("r[0]=%d, r[39999]=%d\n", r[0], r[39999]);

  return 0;
}
