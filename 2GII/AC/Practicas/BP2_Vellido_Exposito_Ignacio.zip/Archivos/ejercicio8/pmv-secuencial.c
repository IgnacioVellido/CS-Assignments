// Resuelto para matrices de enteros

#include <stdlib.h>	// biblioteca con funciones atoi(), malloc() y free()
#include <stdio.h>      // biblioteca donde se encuentra la función printf()
#include <time.h>	// biblioteca donde se encuentra la función clock_gettime()

//#define VECTOR_GLOBAL      // descomentar para que los vectores sean variables ...
			   // globales (su longitud no estará limitada por el ...
			   // tamaño de la pila del programa)

#define VECTOR_DYNAMIC	 // descomentar para que los vectores sean variables ...
			         // dinámicas (memoria reutilizable durante la ejecución)

#ifdef VECTOR_GLOBAL
 #define MAX 30000 	  // Si tamaño máximo de un vector: 2^25, para matrices (2^25)^(1/2)
 long int M[MAX][MAX], v[MAX], r[MAX];
#endif

int main (int argc, char **argv) {
  int N;

  if (argc != 2) {
    printf("Falta el tamanio de la matriz cuadrada\n");
    exit(1);
  }

  N = atoi(argv[1]);

  #ifdef VECTOR_GLOBAL
    if (N>MAX) N=MAX;
  #endif

  #ifdef VECTOR_DYNAMIC
    long int **M, *v, *r;
    M = (long int**) malloc(N*sizeof(long int *));  

    int p;
    for (p=0; p<N; p++) 
      M[p] = (long int*) malloc(N*sizeof(long int));    
    
    v = (long int*) malloc(N*sizeof(long int));   
    r = (long int*) malloc(N*sizeof(long int));

    if ( (M==NULL) || (v==NULL) || (r==NULL) ){
      printf("Error en la reserva de espacio\n");
      exit(-2);
    }
  #endif

  int i, j;

  // Inicialización
  for (i=0; i<N; i++) {
    for (j=0; j<N; j++) {
      M[i][j] = j+1;
    }
    v[i] = i+1;
  }

  long int suma;
  struct timespec cgt1,cgt2; double ncgt; //para tiempo de ejecución

  // Mediciones
  clock_gettime(CLOCK_REALTIME,&cgt1);

  for (i=0; i<N; i++) {
    suma = 0;
    for (j=0; j<N; j++) {
      suma += M[i][j]*v[j];
    }
    r[i] = suma;
  }
  clock_gettime(CLOCK_REALTIME,&cgt2);

  // Calculo de tiempos
  ncgt=(double) (cgt2.tv_sec-cgt1.tv_sec)+
       (double) ((cgt2.tv_nsec-cgt1.tv_nsec)/(1.e+9));

  // Para tamaños pequeños imprimir todas las componentes
  printf("Tiempo(seg.):%11.9f\t / Tamaño Vectores:%u\n",ncgt,N);

  if (N < 15) {
    for(i=0; i<N; i++)
      printf("/ r[%d]=%li /\n", i, r[i]);
  }
  else
    printf("r[0]=%li, r[%d]=%li\n", r[0], N, r[N-1]);

  // Liberar memoria
  #ifdef VECTOR_DYNAMIC
    for (p=0; p<N; p++) 
      free(M[p]);   

    free(M); // libera el espacio reservado para M
    free(v); // libera el espacio reservado para v
    free(r); // libera el espacio reservado para r
  #endif
}

/* 
N = 4
    
    1 2 3 4        1         30
    1 2 3 4        2         30
M = 1 2 3 4    V = 3     R = 30
    1 2 3 4        4         30

*/
