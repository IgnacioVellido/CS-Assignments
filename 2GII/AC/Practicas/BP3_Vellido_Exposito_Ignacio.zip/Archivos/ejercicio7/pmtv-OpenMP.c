// Resuelto para matrices de enteros

#include <stdlib.h>	// biblioteca con funciones atoi(), malloc() y free()
#include <stdio.h>      // biblioteca donde se encuentra la función printf()
#include <time.h>	// biblioteca donde se encuentra la función clock_gettime()

#include <omp.h>

#define VECTOR_DYNAMIC	 // descomentar para que los vectores sean variables ...
			         // dinámicas (memoria reutilizable durante la ejecución)

int main (int argc, char **argv) {
  int N;

  int cores = omp_get_num_procs();
  omp_set_num_threads(cores);

  if (argc != 2) {
    printf("Falta el tamanio de la matriz cuadrada\n");
    exit(1);
  }

  N = atoi(argv[1]);


  long int **M, *v, *r;
  M = (long int**) malloc(N*sizeof(long int *));  

  int p;
  #pragma omp for schedule(runtime)
  for (p=0; p<N; p++) 
    M[p] = (long int*) malloc(N*sizeof(long int));    
   
  v = (long int*) malloc(N*sizeof(long int));   
  r = (long int*) malloc(N*sizeof(long int));

  if ( (M==NULL) || (v==NULL) || (r==NULL) ){
    printf("Error en la reserva de espacio\n");
    exit(-2);
  }

  int i, j;

  // Inicialización
  #pragma omp for private(j) schedule(runtime)
  for (i=0; i<N; i++) {
    for (j=i; j<N; j++) {
      if (i>j)
        M[i][j] = 0;
      else
        M[i][j] = j+1;
    }
    v[i] = i+1;
  }

  long int suma;

  // Mediciones
  double t1, t2, ncgt;
  t1 = omp_get_wtime();

  #pragma omp for private(j, suma) schedule(runtime)
  for (i=0; i<N; i++) {
    suma = 0;
    for (j=i; j<N; j++) {
      suma += M[i][j]*v[j];
    }
    r[i] = suma;
  }
  t2 = omp_get_wtime();

  // Calculo de tiempos
  ncgt = t2 - t1;

  // Para tamaños pequeños imprimir todas las componentes
  printf("Tiempo(seg.):%11.9f\t / Tamaño Vectores:%u\n",ncgt,N);

  if (N < 15) {
    for(i=0; i<N; i++)
      printf("/ r[%d]=%li /\n", i, r[i]);
  }
  else
    printf("r[0]=%li, r[%d]=%li\n", r[0], N, r[N-1]);

  // Liberar memoria
  #pragma omp for schedule(runtime)
  for (p=0; p<N; p++) 
    free(M[p]);   

  free(M); // libera el espacio reservado para M
  free(v); // libera el espacio reservado para v
  free(r); // libera el espacio reservado para r
}

/* 
N = 4
    
    1 2 3 4        1         30
    0 2 3 4        2         29
M = 0 0 3 4    V = 3     R = 25
    0 0 0 4        4         16

*/
