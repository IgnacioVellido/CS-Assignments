// Resuelto para matrices de enteros

#include <stdlib.h>	// biblioteca con funciones atoi(), malloc() y free()
#include <stdio.h>      // biblioteca donde se encuentra la función printf()
#include <time.h>	// biblioteca donde se encuentra la función clock_gettime()

#include <omp.h>

#define VECTOR_DYNAMIC	 // descomentar para que los vectores sean variables ...
			         // dinámicas (memoria reutilizable durante la ejecución)

int main (int argc, char **argv) {
  int N;

  if (argc != 2) {
    printf("Falta el tamanio de la matriz cuadrada\n");
    exit(1);
  }

  N = atoi(argv[1]);


  long int **A, **B, **C;
  A = (long int**) malloc(N*sizeof(long int *));
  B = (long int**) malloc(N*sizeof(long int *));
  C = (long int**) malloc(N*sizeof(long int *));

  int p;
  for (p=0; p<N; p++) {
    A[p] = (long int*) malloc(N*sizeof(long int));
    B[p] = (long int*) malloc(N*sizeof(long int));
    C[p] = (long int*) malloc(N*sizeof(long int));
  }

  if ( (A==NULL) || (B==NULL) || (C==NULL) ){
    printf("Error en la reserva de espacio\n");
    exit(-2);
  }

  int i, j, k;

  // Inicialización
  #pragma omp parallel for private(j)
  for (i=0; i<N; i++) {
    for (j=0; j<N; j++) {
        A[i][j] = j+1;
        B[i][j] = j+1;
    }
  }

  long int suma;

  // Mediciones
  double t1, t2, ncgt;
  t1 = omp_get_wtime();


  #pragma omp parallel for private(j, k)
  for (i=0; i<N; i++) {
    for (j=0; j<N; j++) {
      suma = 0;

      for (k=0 ; k<N; k++)
        suma += A[i][k] * B[k][j];

      C[i][j] = suma;
    }
  }

  t2 = omp_get_wtime();

  // Calculo de tiempos
  ncgt = t2 - t1;

  // Para tamaños pequeños imprimir todas las componentes
  printf("Tiempo(seg.):%11.9f\t / Tamaño Vectores:%u\n",ncgt,N);


  printf("C[0][0]=%li, C[%d][%d]=%li\n",
		C[0][0], N-1, N-1, C[N-1][N-1]);

  // Liberar memoria
  #pragma omp parallel for
  for (p=0; p<N; p++) {
    free(A[p]);
    free(B[p]);
    free(C[p]);
  }

  free(A); free(B); free(C);
}
