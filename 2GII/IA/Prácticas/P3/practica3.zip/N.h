/*
 * N.h
 *
 *  Created on: 2 may. 2018
 *      Author: Ignacio Vellido Expósito
 */

#include "Bot.h"

#ifndef N_H_
#define N_H_

#include <limits>	// Para el valor infinito
#include <chrono>	// Para funciones time

typedef chrono::steady_clock::time_point PuntoClock;
typedef chrono::milliseconds ms;

class N:Bot {
public:
  N();
  ~N();

  void initialize();
  string getName();
  Move nextMove(const vector<Move> &adversary, const GameState &state);

private:
  // Variables -----------------------------------------------------------------
  const int masInfinito   = std::numeric_limits<int>::max(),
            menosInfinito = std::numeric_limits<int>::min();

  Player    miJugador, otroJugador;

  // Tiempos
  long timeout;   // Tiempo del turno
  const int UMBRAL = 1999;	

  bool primeraVez = true; // Necesito inicializar algunas variables ya comenzada la partida

  // Métodos auxiliares --------------------------------------------------------
  Move AlphaBeta(const GameState &state, const PuntoClock &clock_ini);	// Con descenso iterativo mientras haya tiempo

  int Heuristica(const GameState &state);	// Heurística de alpha-beta

  int MaxValor(const GameState &state, int alpha, int beta, const PuntoClock &clock_ini, int profundidad, bool &interrumpido);	// alpha-beta
  int MinValor(const GameState &state, int alpha, int beta, const PuntoClock &clock_ini, int profundidad, bool &interrumpido);	// alpha-beta

  vector<int> PosiblesAcciones(const GameState &state);		// Posiciones que puede marcar un jugador

  int Maximo(int a, int b);					// Máximo de dos valores
  int Minimo(int a, int b);  					// Mínimo de dos valores
};

#endif /* N_H_ */
