/*
 * N.cpp
 * Author: Ignacio Vellido Expósito
 */

#include <string>
#include <cstdlib>
#include <iostream>

#include "N.h"
using namespace std;

N::N() {
	// Inicializar las variables necesarias para ejecutar la partida

}

N::~N() {
	// Liberar los recursos reservados (memoria, ficheros, etc.)
}

void N::initialize() {
	// Inicializar el bot antes de jugar una partida
}

string N::getName() {
	return "N";
}

Move N::nextMove(const vector<Move> &adversary, const GameState &state) {

  // Tiempos
  const PuntoClock clock_ini = chrono::steady_clock::now();

  if (primeraVez) {
    miJugador   = this->getPlayer();
    otroJugador = (miJugador == J1) ? J2 : J1 ;
    primeraVez  = false;
    timeout	= this->getTimeOut();
  }

  Move movimiento = M_NONE;

  // Algoritmo de Alpha-Beta según Russell
  movimiento = AlphaBeta(state, clock_ini);

  return movimiento;
}

//-----------------------------------------------------------------

Move N::AlphaBeta(const GameState &state, const PuntoClock &clock_ini) {
  Move movimiento = (Move) 0,
       nuevoMovimiento;
  GameState hijo;
  vector<int> acciones = PosiblesAcciones(state);

  bool interrumpido = false;
  long actual = 0;
  int n = acciones.size(),
      v,
      maximo = menosInfinito,
      profundidad = 12;

  PuntoClock clock_now;


  while (actual < UMBRAL) {

    maximo = menosInfinito;

    for (int i=0; i<n && !interrumpido; i++) {
      hijo = state.simulateMove((Move) acciones[i]);

      if (hijo.getCurrentPlayer() == miJugador)
        v = MaxValor(hijo, menosInfinito, masInfinito, clock_ini, profundidad, interrumpido);
      else
        v = MinValor(hijo, menosInfinito, masInfinito, clock_ini, profundidad, interrumpido);

      if (!interrumpido && v > maximo) {
        nuevoMovimiento = (Move) acciones[i];
        maximo = v;
      }
    }

    // Es muy posible que en el último descenso no hayamos completado la búsqueda,
    // por tanto solo cambiamos el movimiento si se ha completado
    if (!interrumpido || movimiento == 0)
      movimiento = nuevoMovimiento;

    profundidad++;

    clock_now = chrono::steady_clock::now();
    actual = chrono::duration_cast<ms>(clock_now - clock_ini).count();
  }

  return movimiento;
}

int N::Heuristica(const GameState &state) {
  int puntos = 0;
  Player jugadorActual = state.getCurrentPlayer(),
         noJugadorActual;

  noJugadorActual = (jugadorActual == J1) ? J2 : J1;

  const int x0 = 10,	// Puntuación
            x1 = 5,	// Diferencia de semillas en el tablero
            x2 = 3,	// Turno extra
            x3 = 6,	// Robo del jugador actual (posibilidades de robar)
            x4 = 5,	// Robos del otro jugador (robos a evitar)
	    			x5 = 2;	// Casilla 6


  // Graneros
  puntos += x0 * (state.getScore(miJugador) - state.getScore(otroJugador));

  // Final de partida
  if (state.isFinalState()) {

    // +- Infinito está bien si solo queremos la victoria, pero se quiere ganar por la mayor diferencias
    if (state.getWinner() == miJugador)
      return puntos+1000000;
    else if (state.getWinner() == otroJugador)
      return puntos-1000000;
    else
      return 0;
  }

  int misSemillas, susSemillas,
      lasMias, lasSuyas,	// Para robos
      casilla, x;

  for (int i=1; i<=6; i++) {
    misSemillas = state.getSeedsAt(jugadorActual, (Position) i);
    susSemillas = state.getSeedsAt(noJugadorActual, (Position) (7-i));

    x += misSemillas;
    x -= susSemillas;

    // Semillas en el tablero
    puntos += x1 * (jugadorActual == miJugador) ? x : -x;

    // Turno extra = El nº de semillas coincide con el nº de posición
    if (misSemillas == i)
      puntos += x2 * (jugadorActual == miJugador) ? 1 : -1;

    // Ganar robos
    casilla = i - misSemillas;
    if (casilla > 0) {
      lasSuyas = state.getSeedsAt(noJugadorActual, (Position) (7-casilla));
      lasMias = state.getSeedsAt(jugadorActual, (Position) casilla);

      if ((lasMias == 0) && (lasSuyas != 0))
        puntos += x3 * (jugadorActual == miJugador) ? (lasMias+lasSuyas) : -(lasMias+lasSuyas);
    }

    // Evitar robos
    casilla = i - susSemillas;
    if (casilla > 0) {
      lasSuyas = state.getSeedsAt(noJugadorActual, (Position) (7-casilla));
      lasMias = state.getSeedsAt(jugadorActual, (Position) casilla);

      if ((lasMias != 0) && (lasSuyas == 0))
        puntos += x4 * (jugadorActual == miJugador) ? -(lasMias+lasSuyas) : +(lasMias+lasSuyas);
    }
  }

  // Cuantas más semillas tengas en la última casilla mejor
  puntos += x5 * (int) ( state.getSeedsAt(miJugador, (Position) 6) );

  return puntos;
}

//-----------------------------------------------------------------

int N::MaxValor(const GameState &state, int alpha, int beta, const PuntoClock &clock_ini, int profundidad, bool &interrumpido) {
  PuntoClock clock_now = chrono::steady_clock::now();

  auto a = chrono::duration_cast<std::chrono::milliseconds>(clock_now - clock_ini).count();

  if (a >= UMBRAL) {
   interrumpido = true;
   return Heuristica(state);
  }

  //-------------

  if ((profundidad <= 0) || state.isFinalState())
    return Heuristica(state);

  int v = menosInfinito;
  vector<int> acciones = PosiblesAcciones(state);

  GameState hijo;

  // Para cada acción posible
  for (int i=0; i < acciones.size(); i++) {
    hijo = state.simulateMove((Move) acciones[i]);

    if (hijo.getCurrentPlayer() == miJugador)
      v = Maximo(v, MaxValor(hijo, alpha, beta, clock_ini, profundidad-1, interrumpido));
    else
      v = Maximo(v, MinValor(hijo, alpha, beta, clock_ini, profundidad-1, interrumpido));

    if (v >= beta)
      return v;

    alpha = Maximo(alpha, v);
  }

  return v;
}

int N::MinValor(const GameState &state, int alpha, int beta, const PuntoClock &clock_ini, int profundidad, bool &interrumpido) {
  PuntoClock clock_now = chrono::steady_clock::now();

  auto a = chrono::duration_cast<std::chrono::milliseconds>(clock_now - clock_ini).count();

  if (a >= UMBRAL) {
   interrumpido = true;
   return Heuristica(state);
  }

  if ((profundidad <= 0) || state.isFinalState())
    return Heuristica(state);

  int v = masInfinito;

  vector<int> acciones = PosiblesAcciones(state);

  GameState hijo;

  // Para cada acción posible
  for (int i=0; i < acciones.size(); i++) {
    hijo = state.simulateMove((Move) acciones[i]);

    if (hijo.getCurrentPlayer() == miJugador)
      v = Minimo(v, MaxValor(hijo, alpha, beta, clock_ini, profundidad-1, interrumpido));
    else
      v = Minimo(v, MinValor(hijo, alpha, beta, clock_ini, profundidad-1, interrumpido));

    if (v <= alpha)
      return v;

    beta = Minimo(beta, v);
  }

  return v;
}

//-----------------------------------------------------------------

// Pasarlo por refencia
vector<int> N::PosiblesAcciones(const GameState &state) {
  vector<int> acc;

  for (int i=1; i<=6; i++) { // Hacerlo al revés para ver las de robar primero
    if (state.getSeedsAt( (Player) state.getCurrentPlayer(), (Position) i) > 0) {
      acc.push_back(i);
    }
  }

  return acc;
}

//-----------------------------------------------------------------

int N::Maximo(int a, int b) {
  return (a > b) ? a : b;
}

int N::Minimo(int a, int b) {
  return (a < b) ? a : b;
}

//-----------------------------------------------------------------
