#include "../Comportamientos_Jugador/jugador.hpp"
#include "motorlib/util.h"

#include <iostream>
#include <cmath>

///////////////////  Funciones ////////////////////

//------------------------------------------------------------------------------

ostream& operator<< (ostream &os, const estado &st) {
  os << "Fil: " << st.fila << endl;
  os << "Col: " << st.columna << endl;
  os << "Ori: " << st.orientacion << endl;

  return os;
}

ostream& operator<< (ostream &os, const Nodo &n) {
  os << n.state << "Coste: " << n.coste << endl;

  return os;
}

//------------------------------------------------------------------------------

// Aplicamos MergeSort según lo visto en clase de algorítmica
static void Fusion(vector<Nodo> &v, int inicio, int mitad, int fin) {
  vector<Nodo> aux;

  int izq = inicio,
      dch = mitad;

  while (izq < mitad && dch < fin) { 
    if (v[izq] < v[dch]) { 
      aux.push_back(v[izq]);
      izq++;
    }
    else {
      aux.push_back(v[dch]);
      dch++;
    }   
  }

  while (izq < mitad) {
    aux.push_back(v[izq]);
    izq++;
  }

  while (dch < fin) {
    aux.push_back(v[dch]);
    dch++;
  }  

  for (int i=0; i < aux.size(); i++) 
    v[inicio+i] = aux[i];
}

//------------------------------------------------------------------------------

static void Mergesort(vector<Nodo> &v, int inicio, int fin) {
  if (fin-inicio > 1) {  

    if (fin-inicio == 2) { 
      if (v[inicio] > v[inicio+1]) { // Swap
     	Nodo swap = v[inicio];
	v[inicio] = v[inicio+1];
	v[inicio+1] = swap;
      } 
    }
    else {
      int mitad = (fin - inicio)/2;

      Mergesort(v, inicio, inicio+mitad);
      Mergesort(v, inicio+mitad, fin); 
      Fusion(v, inicio, inicio+mitad, fin);
    }
  }
}

//------------------------------------------------------------------------------

void AnularMatriz(vector<vector<unsigned char> > &m){
	for (int i=0; i<m[0].size(); i++){
		for (int j=0; j<m.size(); j++){
			m[i][j]=0;
		}
	}
}

//------------------------------------------------------------------------------


///////////////////  Métodos ////////////////////

//------------------------------------------------------------------------------

int ComportamientoJugador::interact(Action accion, int valor){
  return false;
}

//------------------------------------------------------------------------------

void ComportamientoJugador::PintaPlan(list<Action> plan) {
	auto it = plan.begin();
	while (it!=plan.end()){
		if (*it == actFORWARD){
			cout << "A ";
		}
		else if (*it == actTURN_R){
			cout << "D ";
		}
		else if (*it == actTURN_L){
			cout << "I ";
		}
		else {
			cout << "- ";
		}
		it++;
	}
	cout << endl;
}


//------------------------------------------------------------------------------

void ComportamientoJugador::VisualizaPlan(const estado &st, const list<Action> &plan){
  AnularMatriz(mapaConPlan);
	estado cst = st;

	auto it = plan.begin();
	while (it!=plan.end()){
		if (*it == actFORWARD){
			switch (cst.orientacion) {
				case 0: cst.fila--; break;
				case 1: cst.columna++; break;
				case 2: cst.fila++; break;
				case 3: cst.columna--; break;
			}
			mapaConPlan[cst.fila][cst.columna]=1;
		}
		else if (*it == actTURN_R){
			cst.orientacion = (cst.orientacion+1)%4;
		}
		else {
			cst.orientacion = (cst.orientacion+3)%4;
		}
		it++;
	}
}


//------------------------------------------------------------------------------

// A* según diapositivas y libro Russell, se añade comprobación de casilla delantera, calculo del coste total y se elimina la comprobación en cerrados
// Se le pasa un int coste, si es distinto de 0, estamos bloqueados por un aldeano y debemos comprobar si la ruta actual no es adecuada

// MEJORA: Dejar de buscar plan si hay que replanificar por un aldeano y el nuevo camino es ya de coste superior

bool ComportamientoJugador::pathFinding(const estado &origen, const estado &destino, list<Action> &plan, bool aldeano, int  &coste) { 
  //Borro el plan anterior
  plan.clear();

  // -- NIVEL 2 --

  // Si hay un aldeano delante mía (se ha pasado true) modifico esa casilla en matriz y al final del método la restauro
  char mapaRe;
  int f, c;

  if (aldeano) {
    f = origen.fila,
    c = origen.columna;

    switch (origen.orientacion) {
      case 0: f--; break;
      case 1: c++; break;
      case 2: f++; break;
      case 3: c--; break;
    }

    mapaRe = matriz[f][c];
    matriz[f][c] = 'Z';
  }  

  // -- FIN NIVEL 2 --

  bool solucion = false;
  Nodo node(origen);		// Estado  inicial

  if (node.state.IgualesFilCol(destino))
    solucion = true;

  Nodo child;			// Hijo
  list<Nodo>   frontier;	// Abierto
  list<Nodo>   explored;	// Cerrado
  list<Action> acciones;	// Posibles acciones a partir de un nodo

  list<Action>::iterator it;
  
  frontier.push_back(node);

  while(!solucion) {    
    if (frontier.empty())
      return false;

    node = frontier.front();
    frontier.pop_front();

    if (node.state.IgualesFilCol(destino)) { 
      #ifdef COMENTARIOS
        cout << "Encontrada solucion" << endl; 
      #endif

      solucion = true; 
      break;	
    }

    explored.push_back(node); 

    PosiblesAcciones(node.state, acciones);
    for (it = acciones.begin(); it != acciones.end(); ++it) { 
      NodoHijo(node, child, *it, destino);

      list<Nodo>::iterator encontrado;

      // enCola devuelve un puntero
      if ((enCola(frontier, child.state) == frontier.end()) && (enCola(explored, child.state) == explored.end())) {
	frontier.push_back(child);
        OrdenarFrontera(frontier);
      }
      else if ((encontrado = enCola(frontier, child.state)) != frontier.end()) {
	if (encontrado->coste > child.coste) {
	  encontrado->state = child.state;
	  encontrado->padre = child.padre;
	  encontrado->accion = child.accion;
	  encontrado->coste = child.coste;

          OrdenarFrontera(frontier);
        }
      }
    }
  } 

  coste = node.coste; // Que es igual a nodo.g

  // Sacar plan retrocediendo por los nodos
  while (node.state != origen) { 
    plan.push_front(node.accion);
    node = *(node.padre);
  }

  // -- NIVEL 2 --

  if (aldeano) {
    matriz[f][c] = mapaRe;
  }

  // -- FIN NIVEL 2 --

  // Descomentar para ver el plan en el mapa
  if (ubicado) {
    estado pintaOrigen = origen;
    pintaOrigen.fila = fil;
    pintaOrigen.columna = col;
    pintaOrigen.orientacion = brujula;

    VisualizaPlan(pintaOrigen, plan);
  }

  return true;
}


//------------------------------------------------------------------------------

void ComportamientoJugador::PosiblesAcciones (Nodo origen, list<Action> &resultado) { 
  // Limpio el contenido anterior
  resultado.clear();

  // Si la casilla de delante es transitable, añadir la acción
  int sig_fila = origen.state.fila,		// Aquí se calcularán las coordenadas de actFORWARD
      sig_colu = origen.state.columna,
      orientacion_casilla = origen.state.orientacion;

  switch (orientacion_casilla) {
    case 0: sig_fila--; break;
    case 1: sig_colu++; break;
    case 2: sig_fila++; break;
    case 3: sig_colu--; break;
  }


  // Si está en el rango de la matriz y es una casilla transitable
  if (sig_fila >= 0 && sig_fila < 200 && sig_colu >= 0 && sig_colu < 200 && PuedoAvanzar(sig_fila, sig_colu))
    resultado.push_back(actFORWARD);
  

  //-----------------
 
  sig_fila = origen.state.fila;			// Aquí se calcularán las coordenadas de actTURN_R
  sig_colu = origen.state.columna;
  orientacion_casilla = origen.state.orientacion;

  // Ver si la de la derecha es transitable
  orientacion_casilla = (orientacion_casilla + 1) % 4;

  switch (orientacion_casilla) {
    case 0: sig_fila--; break;
    case 1: sig_colu++; break;
    case 2: sig_fila++; break;
    case 3: sig_colu--; break;
  }

  if (sig_fila >= 0 && sig_fila < 200 && sig_colu >= 0 && sig_colu < 200 && PuedoAvanzar(sig_fila, sig_colu))
    resultado.push_back(actTURN_R);
  

  //-----------------
 
  sig_fila = origen.state.fila;			// Aquí se calcularán las coordenadas de actTURN_L
  sig_colu = origen.state.columna;
  orientacion_casilla = origen.state.orientacion;

  // Ver si la de la derecha es transitable
  orientacion_casilla = (orientacion_casilla + 3) % 4;

  switch (orientacion_casilla) {
    case 0: sig_fila--; break;
    case 1: sig_colu++; break;
    case 2: sig_fila++; break;
    case 3: sig_colu--; break;
  }

  if (sig_fila >= 0 && sig_fila < 200 && sig_colu >= 0 && sig_colu < 200 && PuedoAvanzar(sig_fila, sig_colu))
    resultado.push_back(actTURN_L);
  
  //-----------------

  // Si no se ha insertado ningún movimiento realizar un giro, puesto que podríamos encontrarnos en una casilla rodeada por precipios menos por detraś
  if (resultado.empty())
    resultado.push_back(actTURN_R);
}

//------------------------------------------------------------------------------

bool ComportamientoJugador::PuedoAvanzar (int fila, int colu) {
  if (matriz[fila][colu] == 'S' || matriz[fila][colu] == 'T' 
                                || matriz[fila][colu] == 'K' 
				|| matriz[fila][colu] == '?') 
      return true;

  return false;
}

//------------------------------------------------------------------------------

void ComportamientoJugador::NodoHijo (Nodo &padre, Nodo &hijo, Action &action, const estado &destino) {
  // CUIDADO CON ESTO, LIBERAR MEMORIA
  // Al hacer pop de la lista FIFO se elimina el padre del nodo, por eso se crea uno en memoria dinámica
  Nodo *parent = new Nodo;
  parent->state = padre.state;
  parent->padre = padre.padre;
  parent->accion = padre.accion;
  parent->coste = padre.coste;
  parent->g = padre.g;

  hijo.state  = ResultadoAccion(padre.state, action);
  hijo.padre  = parent;
  hijo.accion = action;
  hijo.g      = padre.g + StepCost(action);
  hijo.coste  = hijo.g + Heuristica(hijo.state, destino); 		
}

//-------------------------------------------------------------

estado ComportamientoJugador::ResultadoAccion (estado &state, Action &action) {
  estado resultado = state;
 
  switch (action) {
    case actFORWARD: 
      switch (state.orientacion) {
	case 0: resultado.fila--; break;
	case 1: resultado.columna++; break;
	case 2: resultado.fila++; break;
	case 3: resultado.columna--; break;
      }
      break;

    case actTURN_R: resultado.orientacion = (resultado.orientacion + 1) % 4; break;
    case actTURN_L: resultado.orientacion = (resultado.orientacion + 3) % 4; break;
  }

  return resultado;
}

//------------------------------------------------------------------------------

int ComportamientoJugador::StepCost (Action &action) {
  if (action == actFORWARD)
    return 1;
  else
    return 2;
}

//------------------------------------------------------------------------------


int ComportamientoJugador::Heuristica (const estado &origen, const estado &destino) {     
  int total = 0,
      difF = origen.fila - destino.fila,
      difC = origen.columna - destino.columna,
      orientacion_actual = origen.orientacion;

  // Reduzco la distancia en columnas
  if (difC < 0){
    if (orientacion_actual == 0){
      total += 1; 			// Un giro a la derecha
      orientacion_actual = 1;
    }
    else if (orientacion_actual == 3){
      total += 2;			// Dos giros a la derecha
      orientacion_actual = 1;
    }
    else if (orientacion_actual == 2){
      total += 1;			// Un giro a la izquierda
      orientacion_actual = 1;
    }
  }
  else if (difC > 0){
    if (orientacion_actual == 0){
      total += 1;			// Un giro a la izquierda
      orientacion_actual = 3;
    }
    else if (orientacion_actual == 1){
      total += 2;			// Dos giros a la derecha
      orientacion_actual = 3;
    }
    else if (orientacion_actual == 2){
      total += 1; 			// Un giro a la derecha
      orientacion_actual = 3;
    }
  }

  // Movimientos en línea recta
  total += (difC < 0) ? -difC : difC;

  // Reduzco la distancia en filas
  if (difF < 0){
    if (orientacion_actual == 1){
      total += 1; 			// Un giro a la derecha
      orientacion_actual = 2;
    }
    else if (orientacion_actual == 3){
      total += 1; 			// Un giro a la izquierda
      orientacion_actual = 2;
    }
  }
  else if (difF > 0){
    if (orientacion_actual == 1){
      total += 1; 			// Un giro a la izquierda
      orientacion_actual = 0;
    }
    else if (orientacion_actual == 3) {
      total += 1; 			// Un giro a la derecha
      orientacion_actual = 0;
    }
  }

  // Movimientos en línea recta
  total += (difF < 0) ? -difF : difF;

  return total;

}

//------------------------------------------------------------------------------

list<Nodo>::iterator ComportamientoJugador::enCola (list<Nodo> &cola, estado &st) {
  list<Nodo>::iterator it = cola.begin();
  estado comparar;

  for (it; it != cola.end(); ++it) {
    comparar = it->state;

    if (comparar == st)
      return it;
  }

  return it;
}

//------------------------------------------------------------------------------  

// Pasar list a vector
void ComportamientoJugador::OrdenarFrontera (list<Nodo> &lista) { 
  list<Nodo>::iterator it;
  vector<Nodo>::iterator vit;
  vector<Nodo> v;

  for (it = lista.begin(); it != lista.end(); it++)
    v.push_back(*it);

  Mergesort(v, 0, v.size());

  lista.clear();
  for (vit = v.begin(); vit != v.end(); vit++)
    lista.push_back(*vit);

}


//------------------------------------------------------------------------------

Action ComportamientoJugador::think(Sensores sensores) {
  if (!esperando) {
    // Actualizar el efecto de la ultima accion
    switch (ultimaAccion){
      case actTURN_R: brujula = (brujula+1)%4; break;
      case actTURN_L: brujula = (brujula+3)%4; break;
      case actFORWARD:
        switch (brujula){
	  case 0: fil--; filMatriz--; break;
	  case 1: col++; colMatriz++; break;
 	  case 2: fil++; filMatriz++; break;
  	  case 3: col--; colMatriz--; break;
        }

        #ifdef COMENTARIOS
          if (ubicado) 
            cout << "Fil: " << fil << "  Col: " << col << " Or: " << brujula << endl;
          else 
            cout << "Posicion desconocida" << endl;     
        #endif
    }


    // Determinar si ha cambiado el destino desde la ultima planificacion
    if (hayPlan and (sensores.destinoF != destinoMapa.fila or sensores.destinoC != destinoMapa.columna)){
      #ifdef COMENTARIOS
        cout << "El destino ha cambiado" << endl;
      #endif

      hayPlan = false;
    }  


    // Si acabamos de pisar por primera vez un punto PK
    // -- NIVEL 3 --
    if (!ubicado && sensores.mensajeF != -1){
      fil = sensores.mensajeF;
      col = sensores.mensajeC;

      ubicado = true;
      hayPlan = false;	// Si teníamos un plan para llegar a la casilla PK, lo finalizamos. Cuando ya esté ubicado no entrará aquí nunca

      // Al estar ubicado ya sabe el tamaño del mapa, y puede dibujar los precipicios alrededor de él en la matriz
      DibujarMapa();
    }
  

    // Si estoy ubicado Actualizar mapa -- NIVEL 3 ---
    ActualizarMatriz(sensores);
    if (ubicado)
      ActualizarMapa(sensores);
  }
  else if (sensores.superficie[2] != 'a') {
    #ifdef COMENTARIOS
      cout << "Gracias por apartarte" << endl;
    #endif

    esperando = false;
  }

  //--------------------------------------------------------------------------

  // Si nos movemos hacia adelante y hay un obstáculo
  if (!esperando && hayPlan && plan.size() > 0 && plan.front() == actFORWARD)
    if (sensores.superficie[2] == 'a' || (sensores.terreno[2] != 'S' && sensores.terreno[2] != 'T' && sensores.terreno[2] != 'K')) {

    #ifdef COMENTARIOS
      cout << "Obstaculo en el camino. Replanificando" << endl;
    #endif

    estado origen;
    origen.fila = filMatriz;
    origen.columna = colMatriz;
    origen.orientacion = brujula;

    destinoMapa.fila = sensores.destinoF;
    destinoMapa.columna = sensores.destinoC;

    // Si no iba a un punto PK
    if (ubicado) {
      destinoMatriz.fila = filMatriz + sensores.destinoF - fil;  		
      destinoMatriz.columna = colMatriz + sensores.destinoC- col;
    }
    else {
      destinoMatriz.fila = destinoPK.fila;
      destinoMatriz.columna = destinoPK.columna;
    }

    
    // Si el coste del nuevo camino es mucho mayor que el actual y el obstáculo es un aldeano, esperar a que se quite
 
    list<Action> nuevoPlan;
    int nuevoCoste;

    hayPlan = pathFinding(origen, destinoMatriz, nuevoPlan, true, nuevoCoste); 

    if (sensores.superficie[2] == 'a') {
      if ((nuevoCoste-costePlanActual) > (2*nuevoCoste)) {
        esperando = true;

        #ifdef COMENTARIOS
  	  cout << "Aldeano, no me pienso mover hasta que te quites de ahí" << endl;
        #endif
      }
      else {
        plan = nuevoPlan; 
        costePlanActual = nuevoCoste;
      }
    }
    else {
      plan = nuevoPlan; 
      costePlanActual = nuevoCoste;
    }    
  }

  // Determinar si tengo que construir un plan (estoy ubicado)
  if (ubicado && !hayPlan) {
    #ifdef COMENTARIOS
      cout << "Creando ruta" << endl;
    #endif

    estado origen;
    origen.fila = filMatriz;
    origen.columna = colMatriz;
    origen.orientacion = brujula;

    destinoMapa.fila = sensores.destinoF;
    destinoMapa.columna = sensores.destinoC;

    // Transformando las coordenadas de mapaResultado a matriz
    destinoMatriz.fila = filMatriz + sensores.destinoF - fil;  		
    destinoMatriz.columna = colMatriz + sensores.destinoC- col; 

    // Si hay un aldeano delante mía cuando voy a realizar el plan
    bool aldeano = false;
    if (sensores.superficie[2] == 'a')
      aldeano = true;
 
    // Es posible que al crear por primera vez el plan el aldeano ya te esté bloqueando
    // Si tengo tan mala suerte para que me pase eso echo la lotería

    hayPlan = pathFinding(origen, destinoMatriz, plan, aldeano, costePlanActual);
  }

  // Si todavía no me he ubicado  
  if (!ubicado && !hayPlan) {	// No está ubicado y no ha trazado un plan para PK
    bool encontradoPK = false;

    // Buscar una casilla PK en mi visión
    for (int i=0; i<casillasEnVision && !encontradoPK; i++) { // casillasEnVision=16
      if (sensores.terreno[i] == 'K') {
	encontradoPK = true;

	// Calcular coordenadas de PK
	destinoPK = CalcularCoordenadasPK();	
	
	// Trazar plan hasta PK
	estado origen;
	origen.fila = filMatriz;
	origen.columna = colMatriz;
	origen.orientacion = brujula;

        destinoMatriz.fila = sensores.destinoF;
        destinoMatriz.columna = sensores.destinoC;

        bool aldeano = false;
        if (sensores.superficie[2] == 'a')
          aldeano = true;

	hayPlan = pathFinding(origen, destinoPK, plan, aldeano, costePlanActual);
      }
    }    
    
    // No he visto ninguna casilla PK, vagabundeo 
    if (!encontradoPK) {
 
      // Avanzar 6 casillas, girar hacia un lado, avanzar otras 6, girar al otro
      if (!avanzar) {
	if (giro) {
  	  plan.push_back(actTURN_R);
	  giro = false;
	}
	else {
  	  plan.push_back(actTURN_L);
	  giro = true;
        }

        avances = 0;
	avanzar = true;
      }     
      else if ((sensores.terreno[2] == 'S' || sensores.terreno[2] == 'T' || sensores.terreno[2] == 'K') && sensores.superficie[2] != 'a') {
        plan.push_back(actFORWARD);
	avances++;

	if (avances == 6)
	  avanzar = false;
      }
      else {
	if (giro) {
  	  plan.push_back(actTURN_R);
	}
	else {
  	  plan.push_back(actTURN_L);
        }

        avances = 0;
	avanzar = true;	
      }
    }
  }

  //--------------

  // Ejecutar el plan
  Action sigAccion;
  
  if (esperando) {
    sigAccion = actIDLE;
 
    #ifdef COMENTARIOS
      cout << "Y no se quita" << endl;
    #endif
  }
  else if (plan.size()>0){ //(hayPlan and plan.size()>0){
    sigAccion = plan.front(); 
    plan.erase(plan.begin());
  }
  else {
    sigAccion = actIDLE;
   
    #ifdef COMENTARIOS   
      cout << "Uy, no me he movido" << endl;
    #endif
  }

  ultimaAccion = sigAccion;
  return sigAccion;
}

//------------------------------------------------------------------------------

void ComportamientoJugador::DibujarMapa() {
  int fil0 = filMatriz - fil, col0,
      i, j;

  for (i=0, fil0; i<TOPE; i++, fil0++) {
    col0 = colMatriz - col;

    for (j=0, col0; j<TOPE; j++, col0++) {
      if ((i < 3) || (j < 3) || (i >= TOPE-3) || (j >= TOPE-3))
	matriz[fil0][col0] = 'P';

      mapaResultado[i][j] = matriz[fil0][col0];
    }
  }

}

void ComportamientoJugador::ActualizarMatriz(Sensores sensores) {
  switch (brujula) {
    case 0:
      matriz[filMatriz]  [colMatriz]   = sensores.terreno[0];
      matriz[filMatriz-1][colMatriz-1] = sensores.terreno[1];
      matriz[filMatriz-1][colMatriz]   = sensores.terreno[2];
      matriz[filMatriz-1][colMatriz+1] = sensores.terreno[3];
      matriz[filMatriz-2][colMatriz-2] = sensores.terreno[4];
      matriz[filMatriz-2][colMatriz-1] = sensores.terreno[5];
      matriz[filMatriz-2][colMatriz]   = sensores.terreno[6];
      matriz[filMatriz-2][colMatriz+1] = sensores.terreno[7];
      matriz[filMatriz-2][colMatriz+2] = sensores.terreno[8];
      matriz[filMatriz-3][colMatriz-3] = sensores.terreno[9];
      matriz[filMatriz-3][colMatriz-2] = sensores.terreno[10];
      matriz[filMatriz-3][colMatriz-1] = sensores.terreno[11];
      matriz[filMatriz-3][colMatriz]   = sensores.terreno[12];
      matriz[filMatriz-3][colMatriz+1] = sensores.terreno[13];
      matriz[filMatriz-3][colMatriz+2] = sensores.terreno[14];
      matriz[filMatriz-3][colMatriz+3] = sensores.terreno[15];    

      break;

    case 1:
      matriz[filMatriz]  [colMatriz]   = sensores.terreno[0];
      matriz[filMatriz-1][colMatriz+1] = sensores.terreno[1];
      matriz[filMatriz]  [colMatriz+1] = sensores.terreno[2];
      matriz[filMatriz+1][colMatriz+1] = sensores.terreno[3];
      matriz[filMatriz-2][colMatriz+2] = sensores.terreno[4];
      matriz[filMatriz-1][colMatriz+2] = sensores.terreno[5];
      matriz[filMatriz]  [colMatriz+2] = sensores.terreno[6];
      matriz[filMatriz+1][colMatriz+2] = sensores.terreno[7];
      matriz[filMatriz+2][colMatriz+2] = sensores.terreno[8];
      matriz[filMatriz-3][colMatriz+3] = sensores.terreno[9];
      matriz[filMatriz-2][colMatriz+3] = sensores.terreno[10];
      matriz[filMatriz-1][colMatriz+3] = sensores.terreno[11];
      matriz[filMatriz]  [colMatriz+3] = sensores.terreno[12];
      matriz[filMatriz+1][colMatriz+3] = sensores.terreno[13];
      matriz[filMatriz+2][colMatriz+3] = sensores.terreno[14];
      matriz[filMatriz+3][colMatriz+3] = sensores.terreno[15];   

      break;

    case 2:
      matriz[filMatriz]  [colMatriz]   = sensores.terreno[0];
      matriz[filMatriz+1][colMatriz+1] = sensores.terreno[1];
      matriz[filMatriz+1][colMatriz]   = sensores.terreno[2];
      matriz[filMatriz+1][colMatriz-1] = sensores.terreno[3];
      matriz[filMatriz+2][colMatriz+2] = sensores.terreno[4];
      matriz[filMatriz+2][colMatriz+1] = sensores.terreno[5];
      matriz[filMatriz+2][colMatriz]   = sensores.terreno[6];
      matriz[filMatriz+2][colMatriz-1] = sensores.terreno[7];
      matriz[filMatriz+2][colMatriz-2] = sensores.terreno[8];
      matriz[filMatriz+3][colMatriz+3] = sensores.terreno[9];
      matriz[filMatriz+3][colMatriz+2] = sensores.terreno[10];
      matriz[filMatriz+3][colMatriz+1] = sensores.terreno[11];
      matriz[filMatriz+3][colMatriz]   = sensores.terreno[12];
      matriz[filMatriz+3][colMatriz-1] = sensores.terreno[13];
      matriz[filMatriz+3][colMatriz-2] = sensores.terreno[14];
      matriz[filMatriz+3][colMatriz-3] = sensores.terreno[15];

      break;

    case 3:
      matriz[filMatriz]  [colMatriz]   = sensores.terreno[0];
      matriz[filMatriz+1][colMatriz-1] = sensores.terreno[1];
      matriz[filMatriz]  [colMatriz-1] = sensores.terreno[2];
      matriz[filMatriz-1][colMatriz-1] = sensores.terreno[3];
      matriz[filMatriz+2][colMatriz-2] = sensores.terreno[4];
      matriz[filMatriz+1][colMatriz-2] = sensores.terreno[5];
      matriz[filMatriz]  [colMatriz-2] = sensores.terreno[6];
      matriz[filMatriz-1][colMatriz-2] = sensores.terreno[7];
      matriz[filMatriz-2][colMatriz-2] = sensores.terreno[8];
      matriz[filMatriz+3][colMatriz-3] = sensores.terreno[9];
      matriz[filMatriz+2][colMatriz-3] = sensores.terreno[10];
      matriz[filMatriz+1][colMatriz-3] = sensores.terreno[11];
      matriz[filMatriz]  [colMatriz-3] = sensores.terreno[12];
      matriz[filMatriz-1][colMatriz-3] = sensores.terreno[13];
      matriz[filMatriz-2][colMatriz-3] = sensores.terreno[14];
      matriz[filMatriz-3][colMatriz-3] = sensores.terreno[15];   

      break;
  }    
}


void ComportamientoJugador::ActualizarMapa(Sensores sensores) {
  switch (brujula) {
    case 0:
      mapaResultado[fil]  [col]   = sensores.terreno[0];
      mapaResultado[fil-1][col-1] = sensores.terreno[1];
      mapaResultado[fil-1][col]   = sensores.terreno[2];
      mapaResultado[fil-1][col+1] = sensores.terreno[3];
      mapaResultado[fil-2][col-2] = sensores.terreno[4];
      mapaResultado[fil-2][col-1] = sensores.terreno[5];
      mapaResultado[fil-2][col]   = sensores.terreno[6];
      mapaResultado[fil-2][col+1] = sensores.terreno[7];
      mapaResultado[fil-2][col+2] = sensores.terreno[8];
      mapaResultado[fil-3][col-3] = sensores.terreno[9];
      mapaResultado[fil-3][col-2] = sensores.terreno[10];
      mapaResultado[fil-3][col-1] = sensores.terreno[11];
      mapaResultado[fil-3][col]   = sensores.terreno[12];
      mapaResultado[fil-3][col+1] = sensores.terreno[13];
      mapaResultado[fil-3][col+2] = sensores.terreno[14];
      mapaResultado[fil-3][col+3] = sensores.terreno[15];    

      break;

    case 1:
      mapaResultado[fil]  [col]   = sensores.terreno[0];
      mapaResultado[fil-1][col+1] = sensores.terreno[1];
      mapaResultado[fil]  [col+1] = sensores.terreno[2];
      mapaResultado[fil+1][col+1] = sensores.terreno[3];
      mapaResultado[fil-2][col+2] = sensores.terreno[4];
      mapaResultado[fil-1][col+2] = sensores.terreno[5];
      mapaResultado[fil]  [col+2] = sensores.terreno[6];
      mapaResultado[fil+1][col+2] = sensores.terreno[7];
      mapaResultado[fil+2][col+2] = sensores.terreno[8];
      mapaResultado[fil-3][col+3] = sensores.terreno[9];
      mapaResultado[fil-2][col+3] = sensores.terreno[10];
      mapaResultado[fil-1][col+3] = sensores.terreno[11];
      mapaResultado[fil]  [col+3] = sensores.terreno[12];
      mapaResultado[fil+1][col+3] = sensores.terreno[13];
      mapaResultado[fil+2][col+3] = sensores.terreno[14];
      mapaResultado[fil+3][col+3] = sensores.terreno[15];   

      break;

    case 2:
      mapaResultado[fil]  [col]   = sensores.terreno[0];
      mapaResultado[fil+1][col+1] = sensores.terreno[1];
      mapaResultado[fil+1][col]   = sensores.terreno[2];
      mapaResultado[fil+1][col-1] = sensores.terreno[3];
      mapaResultado[fil+2][col+2] = sensores.terreno[4];
      mapaResultado[fil+2][col+1] = sensores.terreno[5];
      mapaResultado[fil+2][col]   = sensores.terreno[6];
      mapaResultado[fil+2][col-1] = sensores.terreno[7];
      mapaResultado[fil+2][col-2] = sensores.terreno[8];
      mapaResultado[fil+3][col+3] = sensores.terreno[9];
      mapaResultado[fil+3][col+2] = sensores.terreno[10];
      mapaResultado[fil+3][col+1] = sensores.terreno[11];
      mapaResultado[fil+3][col]   = sensores.terreno[12];
      mapaResultado[fil+3][col-1] = sensores.terreno[13];
      mapaResultado[fil+3][col-2] = sensores.terreno[14];
      mapaResultado[fil+3][col-3] = sensores.terreno[15];

      break;

    case 3:
      mapaResultado[fil]  [col]   = sensores.terreno[0];
      mapaResultado[fil+1][col-1] = sensores.terreno[1];
      mapaResultado[fil]  [col-1] = sensores.terreno[2];
      mapaResultado[fil-1][col-1] = sensores.terreno[3];
      mapaResultado[fil+2][col-2] = sensores.terreno[4];
      mapaResultado[fil+1][col-2] = sensores.terreno[5];
      mapaResultado[fil]  [col-2] = sensores.terreno[6];
      mapaResultado[fil-1][col-2] = sensores.terreno[7];
      mapaResultado[fil-2][col-2] = sensores.terreno[8];
      mapaResultado[fil+3][col-3] = sensores.terreno[9];
      mapaResultado[fil+2][col-3] = sensores.terreno[10];
      mapaResultado[fil+1][col-3] = sensores.terreno[11];
      mapaResultado[fil]  [col-3] = sensores.terreno[12];
      mapaResultado[fil-1][col-3] = sensores.terreno[13];
      mapaResultado[fil-2][col-3] = sensores.terreno[14];
      mapaResultado[fil-3][col-3] = sensores.terreno[15];   

      break;
  }    
}

//------------------------------------------------------------------------------
// Rango demasiado amplio - areaABuscar sería raízCuadrada(casillasEnVision)
estado ComportamientoJugador::CalcularCoordenadasPK () {
  bool encontrado = false;
  int areaABuscar = casillasEnVision*casillasEnVision;

  int i = filMatriz - casillasEnVision, 
      j;

  if (i < 0)
    i=0;

  for (i; i < (filMatriz + casillasEnVision) && !encontrado; i++) {
    j = colMatriz - casillasEnVision;

    if (j < 0)
      j=0;  

    for (j; j < (colMatriz + casillasEnVision) && !encontrado; j++) {
      if ((i < 200) && (j < 200) && matriz[i][j] == 'K') {
	encontrado = true;       
      }
    }
  }
 
  estado posicion;

  posicion.fila = i-1;
  posicion.columna = j-1;
  posicion.orientacion = -1;

  return posicion;
}


//------------------------------------------------------------------------------
/*
// Búsqueda en anchura según diapositivas y libro Russell
bool ComportamientoJugador::pathFinding(const estado &origen, const estado &destino, list<Action> &plan, bool aldeano) { 
  //Borro el plan anterior
  plan.clear();

  // -- NIVEL 2 --
  // Si hay un aldeano delante mía (se ha pasado true) modifico esa casilla en mapaResultado y al final del método la restauro
  char mapaRe;
  int f, c;

  if (aldeano) {
    f = origen.fila,
    c = origen.columna;

    switch (origen.orientacion) {
      case 0: f--; break;
      case 1: c++; break;
      case 2: f++; break;
      case 3: c--; break;
    }

    mapaRe = mapaResultado[f][c];
    mapaResultado[f][c] = 'Z';
  }
  
  // -- FIN NIVEL 2 --

  bool solucion = false;
  Nodo node(origen);		// Estado  inicial

  if (node.state.IgualesFilCol(destino))
    solucion = true;

  Nodo child;			// Hijo
  list<Nodo>   frontier;	// Abierto
  list<Nodo>   explored;	// Cerrado
  list<Action> acciones;	// Posibles acciones a partir de un nodo

  list<Action>::iterator it;
  
  frontier.push_back(node);

  while(!solucion) {    
    if (frontier.empty())
      return false;

    node = frontier.front();
    frontier.pop_front();

    explored.push_back(node); 

    PosiblesAcciones(node.state, acciones);
    for (it = acciones.begin(); it != acciones.end() && !solucion; ++it) { 
      NodoHijo(node, child, *it, destino);

      if (!enCola(frontier, child.state) && !enCola(explored, child.state)) { 
	if (child.state.IgualesFilCol(destino)) { 
          cout << "Encontrada solucion" << endl; 
	  solucion = true; 	
	}

	frontier.push_back(child);
      }
    }
  } 


  // Sacar plan retrocediendo por los nodos
  while (child.state != origen) { 
    plan.push_front(child.accion);
    child = *(child.padre);
  }

  // -- NIVEL 2 --

  if (aldeano) {
    mapaResultado[f][c] = mapaRe;
  }

  // -- FIN NIVEL 2 --

  // Descomentar para ver el plan en el mapa
  VisualizaPlan(origen, plan);

  return true;
}
*/

