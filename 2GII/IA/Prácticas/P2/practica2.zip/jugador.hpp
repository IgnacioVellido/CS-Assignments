#ifndef COMPORTAMIENTOJUGADOR_H
#define COMPORTAMIENTOJUGADOR_H

#include "comportamientos/comportamiento.hpp"

#include <list>

// Comentar para tener comentarios por terminal
//#define COMENTARIOS

// Objeto estado
struct estado {
  int fila,
      columna,
      orientacion;

  // Si quiero comprobar el estado destino me es irrelevante la orientación
  bool IgualesFilCol (const estado &c) {
    if (c.fila != fila || c.columna != columna)
      return false;

    return true;
  }

  bool operator== (const estado &c) {
    if (c.fila != fila || c.columna != columna || c.orientacion != orientacion) 
      return false;

    return true;
  }


  bool operator!= (const estado &c) {
    return !((*this) == c);
  }
};

// Declaración adelantada para guardar el puntero
struct Nodo;

// Descripción de un nodo según pag.82 de Russell, añadiendo atributos necesarios para A* y funciones de comparación
struct Nodo {
  int g = 0, 
      coste = 0;	// Equivale a la f
  Nodo *padre;
  estado state;
  Action accion;

  Nodo () {}
  Nodo (estado stat) {state = stat;}

  // Operadores
  bool operator< (const Nodo &n) {
    return (coste < n.coste);
  }

  bool operator> (const Nodo &n) {
    return (coste > n.coste);
  }  

  bool operator<= (const Nodo &n) {
    return (coste <= n.coste);
  }

  bool operator>= (const Nodo &n) {
    return (coste >= n.coste);
  }  
};


class ComportamientoJugador : public Comportamiento {
  public:
    ComportamientoJugador(unsigned int size) : Comportamiento(size) {
      // Inicializar Variables de Estado
      fil = col = 99;
      brujula = 0; // 0: Norte, 1:Este, 2:Sur, 3:Oeste
      ultimaAccion = actIDLE;
      hayPlan = false;

      destinoMatriz.fila = -1;
      destinoMatriz.columna = -1;
      destinoMatriz.orientacion = -1;

      destinoMapa.fila = -1;
      destinoMapa.columna = -1;
      destinoMapa.orientacion = -1;

      esperando = false;
      ubicado = false;			


      avances = 0;
      avanzar = true;
      giro = false;

      casillasEnVision = 16;

      // Conoce que las 3 últimas filas/columnas de mapa resultado son precipicios, se modificará en think
      filMatriz = colMatriz = 99;

      for (int i=0; i<200; i++)
        for (int j=0; j<200; j++)
	  matriz[i][j] = '?';
    }

    ComportamientoJugador(std::vector< std::vector< unsigned char> > mapaR) : Comportamiento(mapaR) {
      // Inicializar Variables de Estado
      fil = col = 99;
      brujula = 0; // 0: Norte, 1:Este, 2:Sur, 3:Oeste
      ultimaAccion = actIDLE;
      hayPlan = false;

      destinoMatriz.fila = -1;
      destinoMatriz.columna = -1;
      destinoMatriz.orientacion = -1;

      destinoMapa.fila = -1;
      destinoMapa.columna = -1;
      destinoMapa.orientacion = -1;

      esperando = false;
      ubicado = false;			


      avances = 0;
      avanzar = true;
      giro = false;

      casillasEnVision = 16;

      // Conoce que las 3 últimas filas/columnas de mapa resultado son precipicios, se modificará en think
      filMatriz = colMatriz = 99;

      for (int i=0; i<200; i++)
        for (int j=0; j<200; j++)
	  matriz[i][j] = '?';
    }

    ComportamientoJugador(const ComportamientoJugador & comport) : Comportamiento(comport){}
    ~ComportamientoJugador(){}

    ComportamientoJugador * clone(){return new ComportamientoJugador(*this);}

    Action think(Sensores sensores);
    int interact(Action accion, int valor);
    void PintaPlan(list<Action> plan);
    void VisualizaPlan(const estado &st, const list<Action> &plan);

    //-----------------------------------------------------------

  private:
    //////// Variables de Estado ////////////
    int fil, col, brujula;
    estado destinoMatriz, 
           destinoMapa;
    list<Action> plan;


    // Nuevas Variables de Estado
    Action ultimaAccion;		// Última acción realizada
    bool hayPlan;			// True si hay un plan en marcha

    bool avanzar,			// True si puedo avanzar
         giro;				// True o false para indicar giro a izquierda o derecha (se van alternando)
    int avances;			// Número de avances consecutivos realizados

    bool ubicado;			// True si sé mi posición en el mapa
    int casillasEnVision;		// Número de casillas que puedo ver delante mía formando un "cono"

    int costePlanActual;		// El coste (g final) del plan en marcha
    bool esperando;			// True si el personaje se encuentra esperando a que se aparte un aldeano

    // Como el tamaño máximo es de 100x100, utilizaré una matriz de 200x200 para poder calcular rutas sin estar ubicado (para ir a PK)
    const int TOPE = mapaResultado[0].size();
    char matriz[200][200];
    int filMatriz, colMatriz;
    estado destinoPK;


    ///////// Funciones auxiliares //////////
    
    //// Relacionadas con pathFinding ///
    bool pathFinding(const estado &origen, const estado &destino, list<Action> &plan, bool aldeano, int &coste);

    // Dado un nodo devuelve todas las posibles acciones según el mapa
    void PosiblesAcciones (Nodo origen, list<Action> &resultado);

    // Indica si la casilla de delante es transitable (si es desconocida devuelve true)
    bool PuedoAvanzar (int fila, int colu);

    // Devuelve el nodo hijo al aplicar al padre una acción
    void NodoHijo (Nodo &padre, Nodo &hijo, Action &action, const estado &destino);

    // Devuelve el estado resultante de aplicar a un estado una acción
    estado ResultadoAccion (estado &state, Action &action);

    // Devuelve el coste de una acción
    int StepCost (Action &action);

    // Calcula la heurística de un estado
    int Heuristica (const estado &state, const estado &destino);

    // Devuelve un iterador a la posición del estado en la cola o el iterador end si no lo encuentra
    list<Nodo>::iterator enCola (list<Nodo> &cola, estado &st);

    // Ordena una lista, se aplica para mantener el orden de la frontera en A*
    void OrdenarFrontera (list<Nodo> &lista);


    //-----------------------------------------------------------

    ///// Relacionadas con think ////

    // Actualiza mapaResultado con los valores de matriz
    void DibujarMapa ();

    // Actualizan mapaResultado y matriz según los sensores actuales
    void ActualizarMatriz(Sensores sensores);
    void ActualizarMapa(Sensores sensores);

    // Se rastrea la zona que rodea al personaje en busca de un punto PK, devuelve su estado (para llamar a pathFinding posteriormente)
    estado CalcularCoordenadasPK ();

    //-----------------------------------------------------------
};

#endif
