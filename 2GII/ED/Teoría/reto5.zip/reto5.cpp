#include <iostream>
#include <cstdlib>
#include <ctime>
#include <set>
#include <string.h> 	// Para el memset

using namespace std;

const int M    = 13,
          null = -1;

bool cicla (int a, int c);

int main (int argc, char *argv[]) {

  cout << "Parejas valida para M = " << M << ": " << endl;
  for (int a = 0; a < M; a++) {
    cout << "a = " << a << " | c = " ;
    for (int c = 0; c < M; c++) {
      if (!cicla(a, c))
        cout << c << ", ";
    }
    cout << endl;
  }

  return 0;
}

// -------------------------------------------------------------------------------
void di (int a, int c, int *di) {
  (*di) = (a * (*di) + c) % M;		// a-3, c-1: 1, 4, 6, 5, 2, 0 - !3
					// a-5, c-1: 1, 6, 3, 2, 4, 0 - !5
}

// -------------------------------------------------------------------------------
bool cicla (int a, int c) {
  set<int> posiciones;
  int d = 0;

  for (int i = 0; i < M; i++) { 
    di(a, c, &d);
    if (!posiciones.insert(d).second) 
      return true;      
  }

  return false; 
}
